package com.chernov.inmem;

import java.util.HashMap;
import java.util.Map;

public class OperationFactory {

	protected Map map = defaultMap();
    
    public OperationFactory() {
         super();
    }
    public Operation create(String opName) {
         Class klass = (Class) map.get(opName);
         if (klass == null)
              throw new RuntimeException(getClass() + " was unable to find an action named '" + opName + "'.");
         
              	Operation actionInstance = null;
         try {
              actionInstance = (Operation) klass.newInstance();
         } catch (Exception e) {
              e.printStackTrace();
         }

         return actionInstance;
    }
    protected Map defaultMap() {
         Map map = new HashMap();

         map.put("index", DemoOperation.class);
         map.put("create", CreateOperation.class);
         map.put("retrieve", RetrieveOperation.class);
         map.put("update", UpdateOperation.class);
         map.put("delete", DeleteOperation.class);

         return map;
    }
}
