package com.chernov.inmem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DbServlet
 */
@WebServlet({ "/inmem", "/index.htm", "*.perform" })
public class DbServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private DataBase db;
    protected OperationFactory factory = new OperationFactory();
	//protected ContactBuffer buffer;

    protected String getOperationName(HttpServletRequest request) {
        String path = request.getServletPath();
        return path.substring(1, path.lastIndexOf("."));
   }

   public void service(HttpServletRequest request, HttpServletResponse response) 
     throws 
   	ServletException, IOException {
        Operation operation = factory.create(getOperationName(request));
        String url = operation.perform(request, response);
        if (url != null)
        {
             getServletContext().getRequestDispatcher(url).forward(request, response);
             System.out.println("Answered to request!");
        }
   }

@Override
public void init() throws ServletException {
	super.init();
	db = DataBase.getInstance();
	try {
		URL remote = new URL("http://www.kormetr.ru/contacts.txt");
        URLConnection yc = remote.openConnection();
        BufferedReader in = new BufferedReader(new InputStreamReader(
                                    yc.getInputStream(),"UTF-8"));
		db.regenDB(in);
		
		/*File f_contacts = new File(new URI("http://kormetr.ru/contacts"));
		db.regenDB(f_contacts);*/
	} catch (IOException e) {
		System.out.println("��������..");
		e.printStackTrace();
	}
	//buffer = new ContactBuffer();
	System.out.println("Gotcha!");
}
   
}
