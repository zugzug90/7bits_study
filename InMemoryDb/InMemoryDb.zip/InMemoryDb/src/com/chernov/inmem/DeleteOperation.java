package com.chernov.inmem;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chernov.entity.Contact;
import com.chernov.entity.Criteria;
import com.chernov.entity.User;

public class DeleteOperation implements Operation {

	private DataBase db;

	@Override
	public String perform(HttpServletRequest request,
			HttpServletResponse response) {

		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		db = DataBase.getInstance();
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		//System.out.println("user's list: "+user.getBuffer().getContacts().size());
		String phone = request.getParameter("phone");
		String lastname = request.getParameter("lastname");
		try {
			lastname = new String( lastname.getBytes("ISO-8859-1"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("?param lastname = '"+lastname+"'");
		db.delete(new Criteria(phone,lastname,null,null));
		reNewUserList(user.getBuffer().getContacts(), phone);
		session.setAttribute("user", user);
		return "/" + "inmemDb.jsp";
	}

	@Override
	public void writeToResponseStream(HttpServletResponse response,
			String output) {
		// TODO Auto-generated method stub

	}
	
	/**
	 * User's list got sent without deleted contacts. So, all gets consistence
	 */
	private void reNewUserList(List<Contact> contacts, String phone)
	{
		List<Contact> toDelete = new ArrayList<Contact>();
		for (Contact co: contacts) if (co.getPhone().equals(phone)) toDelete.add(co);
		contacts.removeAll(toDelete);
	}

}
