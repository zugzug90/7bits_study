package com.chernov.inmem;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CreateOperation implements Operation {

	private DataBase db;

	@Override
	public String perform(HttpServletRequest request,
			HttpServletResponse response) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		db = DataBase.getInstance();

		String phone = request.getParameter("phone");
		String f = request.getParameter("lastname");
		String i = request.getParameter("firstname");
		String o = request.getParameter("surname");
		db.insert(f, i, o, phone);
		
		RetrieveOperation retrieve = new RetrieveOperation();
		return retrieve.perform(request, response);
	}

	@Override
	public void writeToResponseStream(HttpServletResponse response,
			String output) {
		// TODO Auto-generated method stub

	}

}
