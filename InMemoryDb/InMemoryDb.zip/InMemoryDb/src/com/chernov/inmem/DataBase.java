package com.chernov.inmem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.chernov.entity.Contact;
import com.chernov.entity.Criteria;

public class DataBase {

	/**
	 * DataBase - is Singleton class!
	 */
	private static DataBase db;
	private final static char[] alphabet = new char[] {
			'�','�','�','�',
			'�','�','�','�',
			'�','�','�','�',
			'�','�','�','�',
			'�','�','�','�',
			'�','�','�','�',
			'�','�','�','�',
			'�','�'};

	private static List<Contact>[] segments;
	private DataBase() 
	{
		segments = new List[alphabet.length];
	};
	
	public static synchronized DataBase getInstance()
	{
		if (db == null) db = new DataBase();
		
		return db;
	}
	
	/**
	 * Raise the db in Memory from simple .txt file at server
	 * @param f getting File from somewhere
	 * @throws IOException
	 */
	public static void regenDB(File f) throws IOException
	{
		FileReader fr = new FileReader(f);
		
		BufferedReader reader = new BufferedReader(fr);
		regenDB(reader);
	}
	
	/**
	 * Define index of Segment (List marked by Letter) in array of List's
	 * @param letter First letter of contact's fio
	 * @return index in array of Lists (of contacts)
	 */
	private static int findProperSegment(char letter)
	{
		for (int i =0; i< alphabet.length; i++)
		{
			if (letter == alphabet[i]) return i;
		}
		
		return -1;
	}
	
	private static void printOutAllDb()
	{
		for (List<Contact> l: segments)
		{
			if (l != null) for (Contact co: l)
				System.out.println("Contact: "+co.getF()+" ; "+co.getPhone());
		}
	}

	public static String printOutDb()
	{
		String s = "";
		for (List<Contact> l: segments)
		{
			if (l != null) for (Contact co: l)
				s+="Contact: "+co.getF()+" ; "+co.getPhone()+"\r\n";
		}
		return s;
	}
	public static void regenDB(InputStream resourceAsStream) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(resourceAsStream));
		regenDB(reader);
		
	}
	
	public static void regenDB(BufferedReader br) throws IOException
	{
		String raw;
		
		while ((raw = br.readLine()) != null)
		{
			String[] params = raw.split('\t'+""); 
			//if (params.length != 4) throw WrongFormatException
			Contact co = new Contact(params[0], params[1], params[2], params[3]);
			int index = findProperSegment(co.getF().charAt(0));
			if (index < 0) continue; //throw ForeignContactException
			if (segments[index] == null ) // If Segment has not been initialized for such Letter..
				segments[index] = new ArrayList<Contact>();
			segments[index].add(co);
		}
		br.close();
		//printOutAllDb();
	}
	
	public int countRows()
	{
		int counter = 0;
		for (List<Contact> l: segments)
			if (l!=null) counter+=l.size();
		return counter;
	}
	/**
	 * CRUD - Retrieve
	 * @param f Surname
	 * @return
	 */
	public List<Contact> retrieve(String f)
	{
		
		char l = f.charAt(0);
		int pos = findProperSegment(l);
		if (pos == -1) return new ArrayList<Contact>(); // return empty list..
		List<Contact> set = new ArrayList<Contact>();
		for (Contact c: segments[pos])
		{
			if (c.getF().equals(f))
			{
				//System.out.println("Beep-Boop");
				set.add(c);
			}
		}
		return set;
	}
	
	public int countSegmentLength(char a)
	{
		return segments[findProperSegment(a)].size();
	}
	
	public List<Contact> retrieve(String f, String i, String o)
	{
			char l = f.charAt(0);
			int pos = findProperSegment(l);
			if (pos == -1) return new ArrayList<Contact>(); // return empty list..
			List<Contact> set = new ArrayList<Contact>();
			for (Contact c: segments[pos])
			{
				if (i.equals("") || i == null)
				{
					if (o.equals("") || o == null)//System.out.println("Beep-Boop");
					set.add(c);
				}
			}
		return set;
	}
	
	public void update(Contact c, String phone)
	{
		c.setPhone(phone);
	}
	
	public void update(Contact c,String firstname, String lastname, String surname, String phone)
	{
		c.setPhone(phone);
		c.setFirstName(firstname);
		c.setLastName(lastname);
		c.setSurname(surname);
	}

	/**
	 * Delete only by SURNAME Criteria..
	 * @param toDelete List with co-SURNAME contacts
	 */
	public void delete(List<Contact> toDelete) {
		char c;
		if (toDelete.size()>0) c = toDelete.get(0).getF().charAt(0);
		else return;
		segments[findProperSegment(c)].removeAll(toDelete);
		
	}
	
	/**
	 * Deleting single Contact by criteria - phone,lastname
	 * @param toDelete
	 */
	public void delete(Criteria c) {
		char ch;
		ch = c.getParam(Criteria.LAST_NAME).charAt(0);
		System.out.println(ch);
		List<Contact> seg = segments[findProperSegment(ch)];
		Contact toDelete = null;
				for (Contact co: seg)
					if (co.getPhone().equals(c.getParam(Criteria.PHONE))) toDelete = co;
			seg.remove(toDelete);
		}

	/**
	 * Insert a single Row
	 * @param f Surname
	 * @param i Name
	 * @param o Second Name
	 * @param phone New Phone
	 */
	public void insert(String f, String i, String o, String phone) {
		int pos = findProperSegment(f.charAt(0));		
		segments[pos].add(new Contact(f, i, o, phone));
	}

	public List<Contact> retrieve(Criteria criteria) {
		List<Contact> base;
		if (criteria.getParam(Criteria.LAST_NAME) != null)
		base = retrieve(criteria.getParam(Criteria.LAST_NAME));
		else 
		{
			base = new ArrayList<Contact>();
			for (List<Contact> l: segments)
			{
				if (l!=null) for(Contact co: l)
					base.add(co);
			}
		}
		
		List<Contact> total = new ArrayList<Contact>();
		
		boolean i;
		boolean o;
		boolean phone;
		
		for (Contact c:base)
		{
			if (criteria.getParam(Criteria.FIRST_NAME)!=null)
			{
				if (c.getI().equals(criteria.getParam(Criteria.FIRST_NAME))) i = true;
				else i = false;
						
			}
			else i = true;
			if (criteria.getParam(Criteria.SURNAME)!=null)
			{
				if (c.getO().equals(criteria.getParam(Criteria.SURNAME))) o = true;
				else o = false;
						
			}
			else o = true;
			if (criteria.getParam(Criteria.PHONE)!=null)
			{
				if (c.getPhone().equals(criteria.getParam(Criteria.PHONE))) phone = true;
				else phone = false;
						
			}
			else phone = true;
			if (i && o && phone) total.add(c);
		}

		return total;
	}
}
