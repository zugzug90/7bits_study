package com.chernov.inmem;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chernov.entity.Contact;
import com.chernov.entity.Criteria;
import com.chernov.entity.User;

public class RetrieveOperation implements Operation {

	private DataBase db;
	@Override
	public String perform(HttpServletRequest request,
			HttpServletResponse response) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		db = DataBase.getInstance();
		
		Enumeration e = request.getAttributeNames();
		String phone = request.getParameter("phone");
		String f = request.getParameter("lastname");
		String i = request.getParameter("firstname");
		String o = request.getParameter("surname");
		
		List<Contact> set = db.retrieve(new Criteria(phone,f,i,o));
		
		String param = null;
		while (e.hasMoreElements())
		{
			param = e.nextElement().toString();
			System.out.println("Param:"+param);
		}
		HttpSession session = request.getSession();
		User user = new User();
		user.getBuffer().fillBuffer(set);
        session.setAttribute("user", user);
		return "/" + "inmemDb.jsp";
	}

	@Override
	public void writeToResponseStream(HttpServletResponse response,
			String output) {
		// TODO Auto-generated method stub

	}

}
