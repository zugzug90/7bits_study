package com.chernov.inmem;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chernov.entity.Contact;
import com.chernov.entity.Criteria;
import com.chernov.entity.User;

public class UpdateOperation implements Operation {

	private DataBase db;

	@Override
	public String perform(HttpServletRequest request,
			HttpServletResponse response) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		db = DataBase.getInstance();
		
		try {
			String phone = new String (request.getParameter("phone").getBytes("UTF-8"),"UTF-8");
			String f = new String (request.getParameter("lastname").getBytes("ISO-8859-1"),"UTF-8");
			String i = new String (request.getParameter("firstname").getBytes("ISO-8859-1"),"UTF-8");
			String o = new String (request.getParameter("surname").getBytes("ISO-8859-1"),"UTF-8");
			
			String phoneNew = new String (request.getParameter("new_phone").getBytes("UTF-8"),"UTF-8");
			String fNew = new String (request.getParameter("new_lastname").getBytes("UTF-8"),"UTF-8");
			String iNew = new String (request.getParameter("new_firstname").getBytes("UTF-8"),"UTF-8");
			String oNew = new String (request.getParameter("new_surname").getBytes("UTF-8"),"UTF-8");
			
			System.out.println("old param phone: "+phone+";old param firstname = "+i);
			System.out.println("new param phone: "+phoneNew+";new param firstname = "+iNew);
			List<Contact> set = db.retrieve(new Criteria(phone,f,i,o));
			System.out.println("found: "+set.size());
			for (Contact contact:set) db.update(contact,iNew,fNew,oNew,phoneNew);
			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");
			user.getBuffer().fillBuffer(set);
			
			session.setAttribute("user", user);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return "/" + "inmemDb.jsp";
	}

	@Override
	public void writeToResponseStream(HttpServletResponse response,
			String output) {
		// TODO Auto-generated method stub

	}

}
