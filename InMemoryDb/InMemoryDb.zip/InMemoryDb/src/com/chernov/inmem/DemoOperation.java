package com.chernov.inmem;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DemoOperation implements Operation {

	@Override
	public String perform(HttpServletRequest request,
			HttpServletResponse response) {
		 return "/" + "inmemDb.jsp";
	}

	@Override
	public void writeToResponseStream(HttpServletResponse response,
			String output) {
		// TODO Auto-generated method stub

	}

}
