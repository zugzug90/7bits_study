package com.chernov.entity;

public class Contact {

	private String lastname;
	private String phone;
	private String surname;
	private String firstname;
	
	public Contact(String f,String i, String o, String phone) { 
		this.lastname = f;
		this.surname = o;
		this.firstname = i;
		this.phone = phone;
	}
	
	public String getF( ){
		return lastname;
	}
	
	public String getI() {
		return firstname;
	}
	
	public String getO() {
		return surname;
	}
	
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
		
	}

	public void setFirstName(String firstname) {
		this.firstname = firstname;
		
	}

	public void setLastName(String lastname) {
		this.lastname = lastname;
		
	}

	public void setSurname(String surname) {
		this.surname = surname;
		
	}
}
