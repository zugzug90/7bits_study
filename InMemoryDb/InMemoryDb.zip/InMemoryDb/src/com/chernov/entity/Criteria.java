package com.chernov.entity;

import java.util.HashMap;
import java.util.Map;

public class Criteria {

	public static final String PHONE = "phone";
	public static final String LAST_NAME = "lastname";
	public static final String FIRST_NAME = "firstname";
	public static final String SURNAME = "surname";
	
	public Map<String,String> assoc = new HashMap<String, String>();
	
	public Criteria(String phone, String f, String i, String o)
	{
		if (!(phone == null || phone.equals(""))) assoc.put(PHONE, phone);
		if (!(f == null || f.equals(""))) assoc.put(LAST_NAME, f);
		if (!(i == null || i.equals(""))) assoc.put(FIRST_NAME, i);
		if (!(o == null || o.equals("") )) assoc.put(SURNAME, o);
	}

	public String getParam(String key)
	{
		return assoc.get(key);
	}
}
