package com.chernov.entity;

import java.util.ArrayList;
import java.util.List;

public class ContactBuffer {

	private List<Contact> contacts;
	
	public void fillBuffer(List<Contact> set)
	{
		contacts = new ArrayList<Contact>();
		contacts.addAll(set);
	}
	public List<Contact> getContacts()
	{
		return contacts;
	}
	
	public ContactBuffer()
	{
		contacts = new ArrayList<Contact>();
	}
}
